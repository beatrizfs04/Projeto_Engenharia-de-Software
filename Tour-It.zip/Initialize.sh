npm i
npm update
node index.js
