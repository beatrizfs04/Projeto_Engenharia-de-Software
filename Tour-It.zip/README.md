# Tour-It - Projeto Engenharia de Software - Composto Por:
- Beatriz Figueiredo Santos » 50473
- Eduardo Pires Valentim de Almeida Abrantes » 50391
- Manoela Padilha de Azevedo » 50034
- Rodrigo Paiva Calado » 49442

## Como Iniciar o Projeto?

- Devem Primeiro que Tudo Abrir este Diretório na Linha de Comandos (CMD) e Fazer o Comando **npm i** ou **npm install** Para Que Todos os Módulos Sejam Instalados de Forma Correta.
- Após Isto, Devem Clicar Duas Vezes no Ficheiro Initialize.bat, Para Que o Projeto Seja Inicializado e Faça Todos os Passos Sozinho
- Finalmente, Devem Abrir o Browser e Colocar o Seguinte URL: *http://localhost:5000*